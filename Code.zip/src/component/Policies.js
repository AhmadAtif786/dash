import React from "react";

const Policies = () => {
  return (
    <>
                     <div
                    class="personal_info_tab_content_box"
                    id="policies_tab_content"
                     >
                    <div class="personal_info_tab_header">
                      <span>Terms & Policies</span>
                    </div>
                       
                       <div class="policies_tab_content_main">
                         <div class="policies_tab_content_data">
                           <h4>Section 1</h4>
                           <div class="policies_tab_content_des">
                             <p>Dolor, amet a auctor elementum ut sit. Ut vitae quis scelerisque 
amet massa hac ut leo, enim. Interdum lobortis interdum tellus eg-
estas nibh. Lorem epsilum elementum ut sit. Ut vitae quis sceleri.</p>
<p>Dolor, amet a auctor elementum ut sit. Ut vitae quis scelerisque 
amet massa hac ut leo, enim. Interdum lobortis interdum tellus eg-
</p>
                           </div>
                         </div>

                         <div class="policies_tab_content_data">
                           <h4>Section 2</h4>
                           <div class="policies_tab_content_des">
                             <p>Dolor, amet a auctor elementum ut sit. Ut vitae quis scelerisque 
amet massa hac ut leo, enim. Interdum lobortis interdum tellus eg-
estas nibh. Lorem epsilum elementum ut sit. Ut vitae quis sceleri.
</p>
                           </div>
                         </div>

                         <div class="policies_tab_content_data">
                           <h4>Section 3</h4>
                           <div class="policies_tab_content_des">
                             <p>Dolor, amet a auctor elementum ut sit. Ut vitae quis scelerisque 
amet massa hac ut leo, enim. Interdum lobortis interdum tellus eg-
estas nibh. Lorem epsilum elementum ut sit. Ut vitae quis sceleri.
</p>
                           </div>
                         </div>
                       </div>


                  </div>
</>
    
);
};

export default Policies;